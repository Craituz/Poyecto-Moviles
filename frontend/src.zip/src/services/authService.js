    import apiClient from "./apiClient";
import AsyncStorage from "@react-native-async-storage/async-storage";

export const login = async (email, password) => {
    try {
        const response = await apiClient.post("/login", { email, password });
        // Axios devuelve la respuesta en .data
        return response.data;
    } catch (error) {
        // Manejo de errores específico de Axios
        throw error.response?.data || { message: "Error de conexión" };
    }
};

export const register = async (name, email, password) => {
    try {
        const response = await apiClient.post("/register", { name, email, password });
        return response.data;
    } catch (error) {
        throw error.response?.data || { message: "Error al registrarse" };
    }
};

export const logout = async () => {
    try {
        await apiClient.post("/logout");
        await AsyncStorage.removeItem("token");
        await AsyncStorage.removeItem("userInfo");
    } catch (error) {
        console.error("Error al cerrar sesión", error);
    }
};